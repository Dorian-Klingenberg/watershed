# AGENTS.md

## Mission
Build a playable exploratory game prototype based on a decaying fantasy world whose ancient infrastructure still shapes the present. The world once had advanced waterworks, mountain ice-domes, weather control, and civilization-scale transport aqueducts. That infrastructure is now failing in ways current people do not fully understand.

The core player fantasy is **not** heroic combat, scripted story, or cinematic spectacle. The core fantasy is:

> explore, diagnose, and intervene in partially understood systems whose local repairs can create distant unintended consequences.

This project should preserve that identity at all times.

---

## What the Game Is
The game is an exploratory **systems-driven fantasy simulation game** with the following pillars:

1. **Ancient hidden infrastructure** still affects daily life.
2. **Water, terrain, settlement, and weather** are linked.
3. The player performs **repairs / interventions / jury-rigged fixes**.
4. **More than one fix can work locally**, but global side effects matter.
5. The world should feel like it is built on top of misunderstood machinery.
6. Magic is a second systemic layer: a slow path of understanding vs a fast path of delegated power.

The player should gradually feel like an engineer-archeologist-cartographer of invisible systems.

---

## What the Game Is Not
Do **not** drift into any of these by default:

- generic fantasy RPG
- lore dump simulator
- combat-first action game
- chosen-one prophecy narrative
- survival crafting treadmill
- purely decorative city builder
- puzzle game with isolated levels and no persistent systemic consequences
- simplistic morality system with obvious good/bad outcomes

Combat, quests, factions, and art direction may exist later, but they are secondary.

---

## Core Design Truths
Always preserve these truths:

### 1. The world is the main character.
The player exists to reveal and interact with the world’s hidden logic.

### 2. Understanding is partial.
The player should rarely have complete certainty.

### 3. Repairs are interventions, not toggles.
A repair is a hypothesis applied to a live system.

### 4. Local success can cause remote failure.
This must be visible in simulation, UI, or downstream world changes.

### 5. Multiple solutions should exist.
The interesting question is not “what is the correct answer?” but “what tradeoff did the player choose?”

### 6. Fast power should be dangerous because it is delegated.
The dark path is not evil because it is visually spooky; it is dangerous because it grants leverage without deep understanding.

### 7. Deep mastery should have a cost.
The light path involves years of study, discipline, perception, and detachment.

---

## High-Level Game Pillars
Use these pillars to evaluate every design decision.

### Pillar A: Infrastructure Archaeology
Players discover, map, inspect, and infer the function of ancient systems.

### Pillar B: Systemic Repair
Players make interventions that alter flows, pressures, access, ecology, and settlement viability.

### Pillar C: Cascading Consequences
Changes propagate. Villages flood, marshes spread, routes reopen, deserts expand, diseases move, markets shift.

### Pillar D: Partial Knowledge
Players act with incomplete models and imperfect instruments.

### Pillar E: Moral Epistemology Through Magic
The two magic paths reflect two ways of acquiring power:
- understanding and alignment
- invocation and delegation

---

## Initial Product Goal
Build a **vertical slice** that proves the core loop:

1. explore a region
2. inspect ancient water infrastructure
3. make one or more repairs or reroutes
4. advance time / simulate outcomes
5. observe intended and unintended effects nearby and elsewhere
6. update the player’s map / notes / model of the system

If this loop is not working, do not overinvest in lore, combat, or content volume.

---

## Preferred Implementation Strategy
Favor a **simulation-backed exploratory sandbox** over a content-heavy RPG.

Implementation should emphasize:
- clear internal models
- inspectable state
- debug overlays
- deterministic or replayable simulation where practical
- data-driven rules where useful
- rapid iteration on consequences

Codex should bias toward structures that make it easy to inspect:
- node/edge networks
- region graphs
- water flow state
- settlement condition metrics
- intervention logs
- event histories

---

## Deliverables to Prefer Early
When starting or resuming work, prioritize:

1. a concise playable prototype
2. a world simulation loop
3. interactive intervention tools
4. visualization / overlays for cause and effect
5. a codex-friendly architecture and documentation

Before adding content breadth, ensure there is a strong **"I changed this and something unexpected happened"** experience.

---

## Required Docs
Read these files at startup before making major decisions:

- `docs/game_vision.md`
- `docs/core_loops.md`
- `docs/world_systems.md`
- `docs/magic_system.md`
- `docs/architecture_guidance.md`
- `docs/roadmap.md`

If proposing changes that conflict with these docs, explain the tradeoff explicitly.

---

## Startup Behavior for Codex
On startup, Codex should:

1. read this file and all required docs
2. summarize the current game pillars in 8-12 bullets
3. identify the current vertical-slice objective
4. propose the smallest next shippable improvement
5. avoid inventing generic fantasy filler that dilutes the concept
6. preserve inspectability and simulation clarity

If the codebase is incomplete, prefer scaffolding that supports the core loop rather than polishing peripheral systems.

---

## Design Tone
The tone should feel like:
- decaying grandeur
- misunderstood infrastructure
- ecological instability
- sacred knowledge partly lost
- practical people living amid legacy systems they barely control
- discovery through interaction, not exposition

---

## Non-Negotiable Success Test
At any point, a player should be able to say:

> I found part of a hidden system, changed it on purpose, and the world reacted in a way that taught me something.

If that is not true, the design has drifted.
