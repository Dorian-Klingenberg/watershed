# Core Loops

## Primary Loop
1. Travel to a location with a visible symptom.
2. Observe clues and inspect nearby infrastructure.
3. Form a hypothesis about what is wrong.
4. Choose an intervention.
5. Apply repair, reroute, release, block, reinforce, or invoke.
6. Advance time or trigger simulation.
7. Observe outcomes locally and downstream.
8. Record new knowledge on the map / journal / system view.

## Example Symptoms
- crop failure
- swamp spread
- flash flooding
- bridge route lost to marsh
- village water shortage
- newly formed desert patch
- fog, mildew, or disease expansion from excess water
- road or canal becoming navigable again after a fix

## Secondary Loop: Knowledge Acquisition
1. Find fragmentary records, diagrams, oral reports, or ruins.
2. Compare them against the observed behavior of the world.
3. Update the player’s mental and in-game model.
4. Unlock better instruments, interpretations, or safer interventions.

## Secondary Loop: Magic Choice
1. Encounter a problem with no easy material fix.
2. Choose disciplined understanding or spirit invocation.
3. Gain capability, but accept different costs and risks.

## Anti-Loop Warning
Do not turn the game into:
- fetch quest repetition
- static “repair X for reward Y” missions with no systemic change
- single-solution puzzles
