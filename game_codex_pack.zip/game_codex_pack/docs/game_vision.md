# Game Vision

## Working Vision
A fantasy exploration and intervention game set in a world whose ancient water-control civilization collapsed long ago, leaving aqueducts, mountain ice-domes, and climate-shaping infrastructure that still partly functions. Present-day societies live amid these remnants without truly understanding them.

The player moves through this world as someone who can observe, infer, and alter systems. Their actions can stabilize or destabilize local and regional conditions.

## Experience Goals
The game should create these feelings:

- curiosity about hidden structure
- respect for interconnected systems
- tension from incomplete knowledge
- satisfaction from successful diagnosis
- surprise from second-order effects
- unease about shortcut power

## Player Fantasy
Not heroism.
Not domination.
Not loot accumulation.

The player fantasy is:

> becoming increasingly capable at reading and intervening in a living world built on forgotten infrastructure and misaligned powers.

## Why This Game Exists
This game exists to let players explore complex systemic consequences through a fantasy world instead of through abstract dashboards alone.

It should make invisible dependencies tangible.
