# Architecture Guidance

## Goal
Support a simulation-forward game whose systems are inspectable, extensible, and easy to iterate on.

## Recommended Conceptual Modules
- `WorldState`
- `RegionState`
- `InfrastructureNode`
- `FlowNetwork`
- `SettlementState`
- `Intervention`
- `ConsequenceSimulator`
- `MagicInfluence`
- `KnowledgeModel`
- `EventLog`
- `DebugOverlay`

## Data Priorities
Prefer explicit state over opaque side effects.

Useful data patterns:
- graphs for infrastructure dependencies
- time-stepped updates
- per-region metrics
- intervention history logs
- event causality notes

## Visualization Priorities
Need early:
- map overlay for water stress / saturation / flow
- highlighting of infrastructure links
- before/after metrics
- visible downstream consequence markers
- simple in-world or debug explanation of why a change happened

## Vertical Slice Bias
The first build only needs enough architecture to support:
- 1 region
- 2-3 settlements
- several infrastructure nodes
- a few intervention types
- visible time progression
- clear consequences

Avoid overengineering generalized RPG systems too early.
